<?php
// Deprecated since 8.1.0